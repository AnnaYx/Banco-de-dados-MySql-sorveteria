-- 1
SET autocommit = FALSE;
START TRANSACTION; 
INSERT INTO papas.pessoa VALUES (NULL, "55885588585", "Okalani", "okalani@papas.org", "25336636363", "558885558");
SET @id_pessoa := (SELECT LAST_INSERT_ID());
INSERT INTO papas.cliente VALUES (@id_pessoa, 0);
INSERT INTO papas.cobranca VALUES (NULL, 0, 0, now());
SET @id_cobranca := (SELECT LAST_INSERT_ID());
INSERT INTO papas.venda VALUES (NULL, NOW(), NOW(), @id_pessoa, NULL, @id_cobranca);
SET @id_venda := (SELECT LAST_INSERT_ID());
COMMIT;

-- 2
START TRANSACTION;
INSERT INTO papas.produto VALUES(NULL,"19.50", "Strawberry Cone", "Sorvete de morango");
SET @id_produto := (SELECT LAST_INSERT_ID());
COMMIT;

-- 3
SET autocommit = FALSE;
START TRANSACTION;
INSERT INTO papas.pessoa VALUES(NULL, '35823396725', 'Ryan Goslin', 'idrive@papas.org', '41997869287', '476290516');
SET  @id_pessoa := (SELECT LAST_INSERT_ID());
INSERT INTO papas.funcionario VALUES(@id_pessoa, '7.00', '2');
INSERT INTO papas.pagamento VALUES(NULL, '7.00', 'Salário ryan', 'Salário', @id_pessoa);
SET  @id_pagamento := (SELECT LAST_INSERT_ID());
COMMIT;

-- 4
START TRANSACTION;
INSERT INTO papas.produto VALUES(NULL,"22.30", "Strawberry Vanilla Frozen Cheesecake", "cheesecake de sorvete de morango");
SET @id_produto := (SELECT LAST_INSERT_ID());
COMMIT;

-- 5
START TRANSACTION;
INSERT INTO papas.produto VALUES(NULL,"22.30", "Fudge Brownie Frozen Cheesecake", "cheesecake de brownie");
SET @id_produto := (SELECT LAST_INSERT_ID());
ROLLBACK;

-- 6
START TRANSACTION;
INSERT INTO papas.produto VALUES(NULL,"22.30", "Snickers Madness Frozen Cheesecake", "cheesecake de snickers");
SET @id_produto := (SELECT LAST_INSERT_ID());
ROLLBACK;

-- 7
START TRANSACTION;
INSERT INTO papas.produto VALUES(NULL,"22.30", "Oreo Nutella Frozen Cheesecake", "cheesecake de nuttela com oreo");
SET @id_produto := (SELECT LAST_INSERT_ID());
ROLLBACK;

-- 8
START TRANSACTION;
SELECT * FROM papas.produto;
INSERT INTO papas.produto VALUES(NULL,"22.30", "White Chocolate Swirl Frozen Cheesecake", "cheesecake de chocolate branco");
SET @id_produto := (SELECT LAST_INSERT_ID());
ROLLBACK;
SELECT * FROM papas.produto;

-- 9
SET autocommit = FALSE;
START TRANSACTION;
SELECT * FROM funcionario f JOIN pessoa p ON p.id_pessoa = f.id_funcionario WHERE f.funcao_id = 2;
UPDATE funcionario SET salario = salario + 500;
SAVEPOINT insert_garcom;
INSERT INTO papas.pessoa VALUES (NULL, "44223322442", "Shannon", "shannon@papas.org", "87789963693", "441223221");
SET @id_pessoa := (SELECT LAST_INSERT_ID());
INSERT INTO papas.funcionario VALUES (@id_pessoa, "5000","2");
SELECT * FROM funcionario f JOIN pessoa p ON p.id_pessoa = f.id_funcionario;
ROLLBACK TO SAVEPOINT insert_garcom;
COMMIT;
SELECT * FROM funcionario f JOIN pessoa p ON p.id_pessoa = f.id_funcionario;

-- 10
SET autocommit = FALSE;
START TRANSACTION;
UPDATE funcionario set salario = salario + 100 WHERE funcionario.funcao_id = 4;
SAVEPOINT insert_zelador;
INSERT INTO papas.pessoa VALUES(NULL, '35823396225', 'saul goodman', 'saul@papas.org', '41996443561', '348721734');
SET  @id_pessoa := (SELECT LAST_INSERT_ID());
INSERT INTO papas.funcionario VALUES(@id_pessoa, '7004.00', '4');
INSERT INTO papas.pagamento VALUES(NULL, '7004.00', 'Salário saul', 'Salário', @id_pessoa);
SET  @id_pagamento := (SELECT LAST_INSERT_ID());
ROLLBACK TO SAVEPOINT insert_zelador;
COMMIT;

