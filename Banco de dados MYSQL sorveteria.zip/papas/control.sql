CREATE USER 'bruna.romano'@'localhost' IDENTIFIED BY 'bruna123'
WITH MAX_QUERIES_PER_HOUR 100
MAX_UPDATES_PER_HOUR 100
MAX_CONNECTIONS_PER_HOUR 4
MAX_USER_CONNECTIONS 2;

CREATE USER 'emmlette'@'localhost' IDENTIFIED BY 'emmlette123'
WITH MAX_QUERIES_PER_HOUR 100
MAX_UPDATES_PER_HOUR 100
MAX_CONNECTIONS_PER_HOUR 4
MAX_USER_CONNECTIONS 2;

CREATE USER 'connor'@'localhost' IDENTIFIED BY 'connor123'
WITH MAX_QUERIES_PER_HOUR 100
MAX_UPDATES_PER_HOUR 100
MAX_CONNECTIONS_PER_HOUR 4
MAX_USER_CONNECTIONS 2;

CREATE USER 'papa.louie'@'localhost' IDENTIFIED BY 'louie123'
 WITH MAX_USER_CONNECTIONS 2;

CREATE USER 'tony'@'localhost' IDENTIFIED BY 'tony123'
WITH MAX_USER_CONNECTIONS 2;

CREATE USER 'mandi'@'localhost' IDENTIFIED BY 'mandi123'
With MAX_USER_CONNECTIONS 2;

CREATE ROLE IF NOT EXISTS 'garçom', 'caixa';
CREATE ROLE IF NOT EXISTS 'dono', 'gerente';

-- PARA OS PRIVILÉGIOS DOS GARÇONS: demos select, insert e update nas tabelas a seguir
-- para que eles possam controlar os pedidos feitos, para quais clientes e as cobranças.
GRANT INSERT, SELECT, UPDATE
ON papas.pedido
TO 'garçom';

GRANT INSERT, SELECT, UPDATE
ON papas.venda
TO 'garçom';

GRANT INSERT, SELECT, UPDATE
ON papas.cobranca
TO 'garçom';

GRANT INSERT, SELECT, UPDATE
ON papas.cobranca_has_forma_cobranca
TO 'garçom';

GRANT INSERT, SELECT, UPDATE
ON papas.forma_cobranca
TO 'garçom';

GRANT INSERT, SELECT, UPDATE
ON papas.pedido_has_produto
TO 'garçom';

-- Na tabela de produtos demos apenas select para que eles vejam quais são os produtos e os preços, não podendo
-- fazer nenhuma alteração.
GRANT SELECT
ON papas.produto
TO 'garçom';

-- PARA O DONO demos privilégios globais em todo o banco
GRANT ALL
ON *.*
TO 'dono'
WITH GRANT OPTION;

-- PARA O GERENTE demos alguns privilégios para que ele possa fazer alterações em todas as tabelas do PAPAS
-- e administrar apenas as tabelas desse banco
GRANT ALTER, CREATE, DELETE, EXECUTE, INSERT, SELECT, UPDATE
ON papas.*
TO 'gerente'
WITH GRANT OPTION;

-- PARA O USUÁRIO MANDI colocamos alguns selects, já que ela é barista, para ver os pedidos a fazer e 
-- os produtos utilizados.
GRANT SELECT (produto_id, pedido_id, qtde)
ON papas.pedido_has_produto
TO 'mandi'@'localhost';

GRANT SELECT (id_pedido, qtde, venda_id, funcionario_id)
ON papas.pedido
TO 'mandi'@'localhost';

GRANT SELECT (id_produto, nome_produto, descricao_produto)
ON papas.produto
TO 'mandi'@'localhost';

GRANT 'garçom' to 'bruna.romano'@'localhost';
GRANT 'garçom' to 'emmlette'@'localhost';
GRANT 'gerente' TO 'tony'@'localhost';
GRANT 'dono' TO 'papa.louie'@'localhost';